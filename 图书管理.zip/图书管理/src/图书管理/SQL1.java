package ͼ�����;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class SQL1 {   


	/**
     * ��������
     * @throws SQLException 
     */
    public static void main(String args[]){
    	
    	

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("�����ɹ�");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_schema?useSSL=false&serverTimezone=UTC","root","11773820");
            System.out.println("���ӳɹ�");
            
           Statement Statement = conn.createStatement();
           ResultSet result =Statement.executeQuery("select * from ע��� where username AND password");
           while(result.next()) {
        	   System.out.print(result.getInt("username")+" ");
           }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            System.out.println("����ʧ��");
        }
    }}     



