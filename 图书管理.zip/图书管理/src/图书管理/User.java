package ͼ�����;

public class User {
	private String username;
    
    /**
     * �û�����
     */
    private String password;
 
    //���췽��
    public User() {
        super();
    }
 
    public User(String username, String password) {
        super();
        this.username = username;
        this.password = password;
    }
 
    //��Ա������
    public String getUsername() {
        return username;
    }
 
    public void setUsername(String username) {
        this.username = username;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
 
    @Override
    public String toString() {
        return "UserBean [username=" + username + ", password=" + password + "]";
    }
     
     
 
}

