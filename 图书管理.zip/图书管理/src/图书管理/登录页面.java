package ͼ�����;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.sql.Statement;


import javax.swing.SwingConstants;
import javax.swing.DropMode;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.EventObject;
import java.awt.event.ActionEvent;
import java.awt.*;
import javax.swing.AbstractAction;
import javax.swing.Action;
public class ��¼ҳ�� extends JFrame {

	


	protected static final String stmt = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					��¼ҳ�� frame1 = new ��¼ҳ��();
					frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				}
			});
		}
			





	/**
	 * Create the frame.
	 */
	public ��¼ҳ��() {
		getContentPane().setLayout(null);
		setBounds(100, 100, 650, 350);		
		setTitle("��¼����");
		
		JPanel panel1 = new JPanel();
		panel1.setLocation(200, 30);
        panel1.setSize(200, 50);      
        getContentPane().add(panel1);
        
        JLabel panel2= new JLabel("��ӭ����ͼ�����ϵͳ��");
        Font fnt = new Font("Serief", Font.ITALIC + Font.BOLD, 18);
        panel2.setFont(fnt);                   
        panel2.setForeground(Color.RED);      
        panel1.add(panel2);
        JLabel jk = new JLabel("ѧ�� ��");
        
        JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801 \uFF1A");
        lblNewLabel_1.setBounds(91, 163, 77, 26);
        getContentPane().add(lblNewLabel_1);
        lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 22));
        
        JLabel lblNewLabel = new JLabel("\u5B66\u53F7 \uFF1A");
        lblNewLabel.setBounds(91, 101, 77, 26);
        getContentPane().add(lblNewLabel);
        lblNewLabel.setFont(new Font("����", Font.PLAIN, 22));
        
        JTextField textField = new JTextField();
        textField.setBounds(200, 101, 262, 30);
        getContentPane().add(textField);
        textField.setColumns(10);
        
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(200, 167, 262, 30);
        getContentPane().add(passwordField);
        
        JButton btnNewButton = new JButton("\u767B\u5F55");
        btnNewButton.addActionListener(new ActionListener() {   	
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				
			
				
				String username1 =textField.getText();
        		String password1= passwordField.getText();     	
        		 try {
        	            Class.forName("com.mysql.cj.jdbc.Driver");
        	            System.out.println("�����ɹ�");
        	            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_schema?useSSL=false&serverTimezone=UTC","root","11773820");
        	            System.out.println("���ӳɹ�");
        	            
        	           Statement Statement = conn.createStatement();
        	           ResultSet result =Statement.executeQuery("select * from ע��� where username AND password;");
        	           while(result.next()) {
        	        	   
        	        	   result.getInt("username");
        	        	   result.getInt("password");
        	        	   
        	        	   	System.out.println(result.getInt("username"));
        	        	   	System.out.println(result.getInt("password"));
        	        	   	System.out.println(username1);
        	        	   	System.out.println(password1);
        	        	   
						if (textField.getText().equals( result.getInt("username"))&& password1.equals(result.getInt("password"))){
							JOptionPane.showMessageDialog(null, "�ɹ�", null, JOptionPane.WARNING_MESSAGE);
        	    			}
        	    				
        	           }  
        	           
        	        } catch (ClassNotFoundException | SQLException e) {
        	            e.printStackTrace();
        	            System.out.println("����ʧ��");
        	            JOptionPane.showMessageDialog(null, "��¼ʧ��", null, JOptionPane.WARNING_MESSAGE);
        	        }
				
				
				
        		if (textField.getText().equals("") || passwordField.getText().equals("")) {
    				JOptionPane.showMessageDialog(null, "�������Ϊ�գ�", "����", JOptionPane.WARNING_MESSAGE);
    			} else if (textField.getText().equals("1917443044") && passwordField.getText().equals("11773820")) {
    				JOptionPane.showMessageDialog(null, "����Ա��¼�ɹ�", null, JOptionPane.WARNING_MESSAGE);
    				setVisible(false);
    				Data newwindow = new Data();
    				newwindow.setVisible(true);
    			
    			}else {
    				JOptionPane.showMessageDialog(null, "��¼ʧ��", null, JOptionPane.WARNING_MESSAGE);
    			}

        			}	
        	
        });
			
        btnNewButton.setBounds(137, 244, 113, 46);
        getContentPane().add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("\u6CE8\u518C");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		zhuce newwindow = new zhuce();
        		newwindow.setVisible(true);
        	}
        });
      




        	






        
        btnNewButton_1.setBounds(378, 244, 113, 46);
        getContentPane().add(btnNewButton_1);
   }

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}

	

























