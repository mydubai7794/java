package ͼ�����;

import java.io.InputStream;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;



public class JDBCUtils {
	private static String url;
	private static String username;
	private static String password;

static {

    // ʹ��properties���������ļ�
    Properties prop = new Properties();
    try {
        InputStream is = JDBCUtils.class.getClassLoader().getResourceAsStream("db.properties");
        prop.load(is);
        // ע����������ȡ�����ļ��е����ݣ�
        String driver = prop.getProperty("driver");
       
       
        driver = prop.getProperty("driver");
        url = prop.getProperty("url");
        username = prop.getProperty("username");
        password = prop.getProperty("password");
        
        Class.forName(driver);
        System.out.println("�����ɹ�");
    } catch (Exception e) {
        e.printStackTrace();
    }
}

// ��ȡ���ݿ�����
public static Connection getConnection() {
    Connection conn = null;
    try {
        conn = DriverManager.getConnection(url, username, password);
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return conn;
}

// �ͷ���Դ
public static void close(Connection conn, Statement stat, ResultSet rs) {
    close(conn, stat);
    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

// �ͷ���Դ
public static void close(Connection conn, Statement stat) {
    if (conn != null) {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    if (stat != null) {
        try {
            stat.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
}





